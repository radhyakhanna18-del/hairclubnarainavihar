HAIR CLUB WEBSITE - UPLOAD GUIDE

Upload ONLY index.html to your free host (Netlify Drop, Cloudflare Pages or GitHub Pages).
All photos, styles and code are already inside index.html, so no other file is needed for the link to open.

The images-backup folder is only a safe copy of the photos used on the site. Do NOT upload it unless you want to keep copies.

To change something later, edit index.html and upload it again. The link stays the same.
